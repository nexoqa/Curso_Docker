# Workshop - Integration tests with Docker

[![Build Status](https://travis-ci.org/fllaca/workshop-itests-docker.svg?branch=master)](https://travis-ci.org/fllaca/workshop-itests-docker)
[![codecov](https://codecov.io/gh/fllaca/workshop-itests-docker/branch/master/graph/badge.svg)](https://codecov.io/gh/fllaca/workshop-itests-docker)

Sample code for integration tests with Docker Compose

[Exercices](docs/)

[Slides](docs/Testing_with_Docker.pdf)


