git clone git@github.com:fllaca/workshop-itests-docker.git
cd workshop-itests-docker/simplequeue