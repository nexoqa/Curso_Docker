docker run -d --name some-redis -p 6379:6379 redis:4-alpine
