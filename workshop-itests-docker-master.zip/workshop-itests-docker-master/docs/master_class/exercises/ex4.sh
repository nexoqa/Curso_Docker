docker-compose up -d
docker-compose run test-runner mvn -f /src verify
