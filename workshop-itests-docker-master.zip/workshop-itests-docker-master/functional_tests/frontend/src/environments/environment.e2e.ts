export const environment = {
  production: false,
  backend: "/api"
};
