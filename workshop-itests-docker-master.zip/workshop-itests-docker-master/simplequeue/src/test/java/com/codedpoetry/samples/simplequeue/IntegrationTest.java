package com.codedpoetry.samples.simplequeue;

public class IntegrationTest {

}
